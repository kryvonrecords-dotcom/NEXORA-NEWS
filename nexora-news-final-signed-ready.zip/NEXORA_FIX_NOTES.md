# NEXORA-NEWS — Correção dos erros de Kotlin

Corrigidos os dois erros reportados pelo GitHub Actions:

- `CategoryAdapter.kt`: `CategoryAdapter.CategoryViewHolder` agora corresponde à classe interna `CategoryViewHolder`.
- `NewsAdapter.kt`: `NewsAdapter.NewsViewHolder` agora corresponde à classe interna `NewsViewHolder`.

O aviso sobre `compileSdk = 35` e Android Gradle Plugin 8.5.2 é apenas um WARNING; não foi a causa do BUILD FAILED.

Observação: o ZIP original não contém `gradle-wrapper.jar`. Esta correção não fabrica esse binário. O build do GitHub que você mostrou conseguiu executar `./gradlew`, portanto o wrapper está sendo disponibilizado/gerado no ambiente de CI.
