# NEXORA-NEWS — correção de assinatura Debug

O `android/app/build.gradle` foi ajustado para que o build Debug use
`signingConfigs.debug`.

O workflow deve executar `assembleDebug` e, depois, verificar o APK com
`apksigner verify --verbose` antes de publicar o artefato.

Importante: este arquivo não contém uma keystore privada. A assinatura Debug
usa a keystore de debug criada/gerida pelo ambiente Android/Gradle.
