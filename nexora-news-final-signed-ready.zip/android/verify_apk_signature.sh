#!/usr/bin/env bash
set -euo pipefail
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
  echo "ERRO: APK não encontrado: $APK"
  exit 1
fi
if command -v apksigner >/dev/null 2>&1; then
  echo "Verificando assinatura do APK..."
  apksigner verify --verbose "$APK"
  echo "APK assinado e válido."
else
  echo "AVISO: apksigner não encontrado; a verificação será feita pelo Android SDK no workflow."
fi
