export interface RSSSource {
name: string;
url: string;
category: string;
country: string;
}

export const RSS_SOURCES: RSSSource[] = [
{
name: 'Agência Brasil',
url: 'https://agenciabrasil.ebc.com.br/feed/ultimasnoticias/feed.xml',
category: 'brasil',
country: 'Brasil'
},
{
name: 'G1',
url: 'https://g1.globo.com/rss/g1/',
category: 'brasil',
country: 'Brasil'
},
{
name: 'CNN Brasil',
url: 'https://www.cnnbrasil.com.br/feed/',
category: 'brasil',
country: 'Brasil'
},
{
name: 'Estadão',
url: 'https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/politica/?body=%7B%22layout%22:%22google-news%22%7D',
category: 'brasil',
country: 'Brasil'
},
{
name: 'InfoMoney',
url: 'https://www.infomoney.com.br/feed/',
category: 'brasil',
country: 'Brasil'
}
];
